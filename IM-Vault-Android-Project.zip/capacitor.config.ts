import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.imvault.app',
  appName: 'IM Vault',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
