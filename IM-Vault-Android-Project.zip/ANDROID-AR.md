# تحويل IM Vault إلى تطبيق Android APK

هذا المشروع مجهز ليعمل كتطبيق Android مستقل باستخدام Capacitor. ملفات الواجهة تُضمّن داخل التطبيق؛ لا يحتاج التطبيق إلى استضافة موقع أو اتصال إنترنت أثناء الاستخدام العادي.

## أسهل طريقة على الكمبيوتر

1. ثبّت Node.js (الإصدار 22 أو أحدث) و Android Studio.
2. فك ضغط المشروع.
3. افتح Terminal داخل مجلد المشروع ونفّذ:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

4. في Android Studio انتظر اكتمال Gradle Sync.
5. من القائمة اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. بعد انتهاء البناء اختر **locate** للوصول إلى ملف APK.

## تحديث التطبيق بعد تعديل الواجهة

```bash
npm run android:sync
npx cap open android
```

ثم أعد بناء APK من Android Studio.

## ملاحظات

- اسم التطبيق: IM Vault
- معرّف Android: `com.imvault.app`
- التطبيق يضمّن ملفات الواجهة محلياً، لذلك لا يعتمد على Netlify أو موقع مستضاف.
- وظائف التشفير تعتمد على Web Crypto وArgon2id/WASM. يجب اختبارها على جهاز Android فعلي بعد البناء.
- لا تضع مفاتيح أو أسراراً داخل ملفات الواجهة. راجع إعدادات الأمان قبل توزيع التطبيق.
- هذا الملف هو مشروع مصدر جاهز للتغليف، وليس APK مبنياً بالفعل؛ إنشاء APK النهائي يحتاج Android SDK/Android Studio على جهاز بناء.
